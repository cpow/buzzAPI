#!/bin/sh

#Source the commands file
. ~/.bash_profile
number=0

echo "going to do some people stuff... on `date`"
cat `dirname $0`/strings.txt | while read people; do
	oacurl -k "$people" | tee `dirname $0`/file.txt
	
	sleep 2
	
	cat `dirname $0`/file.txt | grep error
	
	  if [ $? -eq 0 ]; then
			echo "" 
	  		echo "The people string number $number failed on `date`" 
			echo "" 
	  else
			echo ""
	  		echo "The people string number $number passed!! :) on `date`"
			echo ""
	  fi
	
	number=$((number+1))
done