#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh

echo ""
echo "Like a post on `date`"
echo ""

echo 'this is how you like a post' | oacurl -X PUT "https://www.googleapis.com/buzz/v1/activities/@me/@liked/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144?prettyprint=true" | tee `dirname $0`/file.txt
didThisFail

sleep 3
echo ""
echo "Unlike a post on `date`"
echo ""
oacurl -X DELETE "https://www.googleapis.com/buzz/v1/activities/@me/@liked/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144?prettyprint=true" | tee `dirname $0`/file.txt
didThisFail


sleep 3
echo ""
echo "mute a post on `date`"
echo ""
echo '' | oacurl -X PUT "https://www.googleapis.com/buzz/v1/activities/@me/@muted/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144?prettyprint=true" | tee `dirname $0`/file.txt
didThisFail

sleep 3
echo ""
echo "unmute a post on `date`"
echo ""
curl -X DELETE "https://www.googleapis.com/buzz/v1/activities/@me/@muted/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144?prettyprint=true" | tee `dirname $0`/file.txt
didThisFail

sleep 5
echo ""
echo "Update a post on `date`"
echo ""
echo \
  '<entry xmlns:activity="http://activitystrea.ms/spec/1.0/"
          xmlns:poco="http://portablecontacts.net/ns/1.0"
          xmlns:georss="http://www.georss.org/georss"
          xmlns:buzz="http://schemas.google.com/buzz/2010">
    <activity:object>
      <activity:object-type>http://activitystrea.ms/schema/1.0/note</activity:object-type>
      <content>Go Redsox!</content>
    </activity:object>
    <georss:point>42.370498 -71.083603</georss:point>
  </entry>' \
  | oacurl -X PUT "https://www.googleapis.com/buzz/v1/activities/@me/@self/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144?prettyprint=true" | tee `dirname $0`/file.txt
didThisFail
