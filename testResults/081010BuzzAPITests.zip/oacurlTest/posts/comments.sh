#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh



echo ""
echo "creating a comment on `date`"
echo ""
echo \
  '<entry xmlns:activity="http://activitystrea.ms/spec/1.0/"
          xmlns:poco="http://portablecontacts.net/ns/1.0"
          xmlns:buzz="http://schemas.google.com/buzz/2010">
    <activity:object-type>http://activitystrea.ms/schema/1.0/comment</activity:object-type>
    <content>My comment</content>
  </entry>' \
  | oacurl -X POST "https://www.googleapis.com/buzz/v1/activities/buzzapiplayground/@self/tag:google.com,2010:buzz:z12ltdq4bky1tzw5004cftt4msq3y3kj144/@comments?prettyprint=true" | tee `dirname $0`/file.txt

didThisFail

sleep 3
echo ""
echo "deleting a comment on `date`"
echo ""
oacurl -X DELETE "https://www.googleapis.com/buzz/v1/activities/117168590257167937559/@self/tag%3Agoogle.com%2C2010%3Abuzz%3Az12ltdq4bky1tzw5004cftt4msq3y3kj144/@comments/tag%3Agoogle.com%2C2010%3Abuzz-comment%3Az12ltdq4bky1tzw5004cftt4msq3y3kj144%3A1273777322692000" | tee `dirname $0`/file.txt

didThisFail

sleep 3
echo ""
echo "Updating a comment on `date`"
echo ""
echo \
  '<entry xmlns:activity="http://activitystrea.ms/spec/1.0/"
          xmlns:poco="http://portablecontacts.net/ns/1.0"
          xmlns:buzz="http://schemas.google.com/buzz/2010">
    <activity:object-type>http://activitystrea.ms/schema/1.0/comment</activity:object-type>
    <content>My new comment</content>
  </entry>' \
  | oacurl -X PUT "https://www.googleapis.com/buzz/v1/activities/buzzapiplayground/@self/tag:google.com,2010:buzz:z12pvbwzirbcdf0cf22yid4q5kzkw3sd1/@comments/tag:google.com,2010:buzz-comment:z12ltdq4bky1tzw5004cftt4msq3y3kj144:1273777369071000?prettyprint=true" | tee `dirname $0`/file.txt

didThisFail
