#!/bin/sh

#function to find failure text within output of oacurl command

didThisFail ()
{	
	cat `dirname $0`/file.txt | grep error
	
	  if [ $? -eq 0 ]; then
 		echo "" 
   		echo "This failed on `date`" 
 		echo "" 
	  else
			cat `dirname $0`/file.txt | grep exception
			if [ $? -eq 0 ]; then
				echo "" 
		  		echo "This failed on `date`" 
				echo ""
			else
				echo ""
	  			echo "This passed!! :) on `date`"
				echo ""
			fi
	  fi
}