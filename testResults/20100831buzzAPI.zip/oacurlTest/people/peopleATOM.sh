#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh



echo "going to do some people stuff... on `date`"
cat `dirname $0`/stringsATOM.txt | while read people; do
	oacurl -k "$people" | tee `dirname $0`/file.txt
	
	sleep 2
	
	didThisFail > output.txt

	if [ $? -eq 0 ]; then
		echo ""
		echo "passed Test `date`"
		echo ""
	else
		echo""
		echo "failed test `date`"
		echo ""
	fi
	
	sleep 2
	
	passATOM > output.txt
	
	if [ $? -eq 0 ]; then
		echo ""
		echo "passed ATOM Test `date`"
		echo ""
	else
		echo""
		echo "failed ATOM test `date`"
		echo ""
	fi
	
	number=$((number+1))
done
