#!/bin/sh

#function to find failure text within output of oacurl command

didThisFail ()
{	
	cat `dirname $0`/file.txt | grep error
	
	  if [ $? -eq 0 ]; then
 		echo "" 
   		echo "This failed on `date`" 
 		echo "" 
	  else
			cat `dirname $0`/file.txt | grep exception
			if [ $? -eq 0 ]; then
				echo "" 
		  		echo "This failed on `date`" 
				echo ""
			else
				echo ""
	  			echo "This passed!! :) on `date`"
				echo ""
			fi
	  fi
}

passJSON () 
{
	cat `dirname $0`/file.txt | grep { | > output.txt
		if [ $? -eq 0 ]; then
			echo ""
			echo "This is a JSON response, passed JSON test `date`"
			echo ""
		else
			cat `dirname $0`/file.txt | grep '<'
				if [ $? -eq 0 ]; then
					echo ""
					echo "This is an ATOM response, FAILED JSON test `date`"
					echo ""
				else
					echo ""
					echo "something went wrong, failed `date`"
					echo ""
				fi
			fi
}

passATOM () 
{
	cat `dirname $0`/file.txt | grep '<'
		if [ $? -eq 0 ]; then
			echo ""
			echo "This is an ATOM response, passed ATOM test `date`"
			echo ""
		else
			cat `dirname $0`/file.txt | grep {
				if [ $? -eq 0 ]; then
					echo ""
					echo "This is a JSON response, FAILED ATOM test `date`"
					echo ""
				else
					echo ""
					echo "something went wrong, failed `date`"
					echo ""
				fi
			fi
}