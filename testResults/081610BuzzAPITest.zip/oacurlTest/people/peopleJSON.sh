#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh



echo "going to do some people stuff... on `date`"
cat `dirname $0`/stringsJSON.txt | while read people; do
	oacurl -k "$people" | tee `dirname $0`/file.txt
	
	sleep 2
	
	didThisFail
	
	sleep 2
	
	passJSON > output.txt
	
	if [ $? -eq 0 ]; then
		echo ""
		echo "passed JSON Test `date`"
		echo ""
	else
		echo""
		echo "failed JSON test `date`"
		echo ""
	fi
	
	number=$((number+1))
done