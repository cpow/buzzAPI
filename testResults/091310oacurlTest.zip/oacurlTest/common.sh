#!/bin/sh

#function to find failure text within output of oacurl command

didThisFail ()
{	
	cat `dirname $0`/file.txt | grep error 
	
	  if [ $? -eq 0 ]; then
   		echo "This failed on `date`" 
	  else
		cat `dirname $0`/file.txt | grep exception 
			if [ $? -eq 0 ]; then
		  		echo "This failed on `date`" 
			else
	  			echo "This passed!! :) on `date`" 
			fi
	  fi
}

passJSON () 
{
	cat `dirname $0`/file.txt | grep { > ouput.txt
		if [ $? -eq 0 ]; then
			echo "This is a JSON response, passed JSON test `date`"
		else
			cat `dirname $0`/file.txt | grep "<" > output.txt
				if [ $? -eq 0 ]; then
					echo "This is an ATOM response, FAILED JSON test `date`"
				else
					echo "something went wrong, failed `date`"
				fi
			fi
}

passATOM () 
{
	cat `dirname $0`/file.txt | grep "<" > output.txt
		if [ $? -eq 0 ]; then
			echo "This is an ATOM response, passed ATOM test `date`"
		else
			cat `dirname $0`/file.txt | grep { > output.txt
				if [ $? -eq 0 ]; then
					echo "This is a JSON response, FAILED ATOM test `date`"
				else
					echo "something went wrong, failed `date`"
				fi
			fi
}
