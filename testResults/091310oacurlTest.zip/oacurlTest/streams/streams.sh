#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh


number=1

echo ""
echo "starting with Searches... on `date`"
echo ""
sleep 5

cat `dirname $0`/searchStrings.txt | while read search; do
	echo ""
	echo "Search String is: $search"

	oacurl "$search" >> `dirname $0`/file.txt
	
	sleep 2
	
	passATOM
	
	cat `dirname $0`/file.txt | grep error > output.txt
	if [ $? -eq 0 ]; then
		echo "The search string number $number failed with $?"
	else
		echo "The search string number $number passed!! :)"
	fi
	

done


echo ""
echo "Now moving on to My Streams... on `date`"
echo ""
sleep 5

cat `dirname $0`/myStreams.txt | while read myStream; do
	echo ""
	echo "my Stream String is: $myStream"

	oacurl "$myStream" >> `dirname $0`/file.txt
	
	sleep 2
	
	passATOM
	
	cat `dirname $0`/file.txt | grep error > output.txt
	if [ $? -eq 0 ]; then
		echo "My stream number $number failed with $?"
	else
		echo "My stream number $number passed!! :)"
	fi
	

done


echo ""
echo "Now moving on to Loaded Streams... on `date`"
echo ""
sleep 5

cat `dirname $0`/loadedStreams.txt | while read loadedStream; do
	echo ""
	echo "Loaded Stream string: $loadedStream"
	oacurl "$loadedStream" >> `dirname $0`/file.txt
	
	sleep 2
	
	passATOM
	
	cat `dirname $0`/file.txt | grep error > output.txt
	if [ $? -eq 0 ]; then
		echo "Loaded stream number $number failed with $?"
	else
		echo "Loaded stream number $number passed!! :)"
	fi
	

done



echo ""
echo "Now moving on to user Streams... on `date`"
echo ""
sleep 5

cat `dirname $0`/userStreams.txt | while read userStream; do
	echo ""
	echo "user stream is: $userStream"
	oacurl "$userStream" >> `dirname $0`/file.txt
	
	sleep 2
	
	passATOM
	
	cat `dirname $0`/file.txt | grep error > output.txt
	if [ $? -eq 0 ]; then
		echo "user stream number $number failed with $?"
	else
		echo "user stream number $number passed!! :)"
	fi
	
done