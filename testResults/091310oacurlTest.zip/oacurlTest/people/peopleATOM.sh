#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh



cat `dirname $0`/stringsATOM.txt | while read people; do
	echo ""
	echo "The string being tested: $people"
	
	oacurl -k "$people" >> `dirname $0`/file.txt 2>&1 &
	
	sleep 2
	
	didThisFail
	
	sleep 2
	
	passATOM
	
done
