#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh



echo "going to do some people stuff... on `date`"
cat `dirname $0`/stringsJSON.txt | while read people; do
	echo ""
	echo "the string being tested: $people"
	
	oacurl -k "$people"  >> `dirname $0`/file.txt
	
	sleep 2
	
	didThisFail
	
	
	sleep 2
	
	passJSON
	
done
