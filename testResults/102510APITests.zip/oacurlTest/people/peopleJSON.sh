#!/bin/sh

#Source the commands file
. ~/.bash_profile
. ~/Documents/uTest/buzzAPI/oacurlTest/common.sh




cat `dirname $0`/stringsJSON.txt | while read people; do

	
	oacurl -k "$people"  >> `dirname $0`/file.txt
	
	sleep 2
	
	didThisFail
	
	
	sleep 2
	
	passJSON
	
	echo "People Strings JSON,$people,$PASSFAIL,$PASSFAILJSON" >> CSVResults.csv
	
done
